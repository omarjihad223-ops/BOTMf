import React, { useEffect, useState } from 'react';
import { api, ApiError } from '../services/api';
import { LoadingScreen } from '../components/Common';
import { MeResponse } from '../types';

interface AdminPrize {
  key: string;
  name: string;
  baseWeight: number;
  stock: number;
  isUnlimited: boolean;
  isActive: boolean;
  deliveredCount: number;
  pendingCount: number;
}

interface Withdrawal {
  _id: string;
  telegramId: number;
  username?: string;
  prizeNameSnapshot: string;
  requestedAt: string;
}

type AdminTab = 'prizes' | 'withdrawals' | 'developers' | 'settings';

export function AdminPage({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<AdminTab>('prizes');

  return (
    <div className="app-content" style={{ paddingBottom: 100 }}>
      <div className="header-row">
        <h2 style={{ margin: 0 }}>👨‍💻 لوحة المطور</h2>
        <button className="btn btn-secondary" style={{ width: 'auto', padding: '8px 16px' }} onClick={onClose}>
          إغلاق ✕
        </button>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
        {(['prizes', 'withdrawals', 'developers', 'settings'] as AdminTab[]).map((t) => (
          <button
            key={t}
            className={`pill`}
            style={{ flex: 1, justifyContent: 'center', background: tab === t ? 'var(--accent)' : undefined, cursor: 'pointer', border: 'none' }}
            onClick={() => setTab(t)}
          >
            {t === 'prizes' ? '🎁 الجوائز' : t === 'withdrawals' ? '📋 الطلبات' : t === 'developers' ? '👥 المطورين' : '⚙️ الإعدادات'}
          </button>
        ))}
      </div>

      {tab === 'prizes' && <PrizesTab />}
      {tab === 'withdrawals' && <WithdrawalsTab />}
      {tab === 'developers' && <DevelopersTab />}
      {tab === 'settings' && <SettingsTab />}
    </div>
  );
}

interface Developer {
  telegramId: number;
  username?: string;
  role: 'owner' | 'developer';
  createdAt: string | null;
}

function DevelopersTab() {
  const [devs, setDevs] = useState<Developer[] | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const [devsRes, meRes] = await Promise.all([
      api.get<{ ok: true; developers: Developer[] }>('/admin/developers'),
      api.get<MeResponse>('/me'),
    ]);
    setDevs(devsRes.developers);
    setIsOwner(meRes.adminRole === 'owner');
  }

  useEffect(() => {
    load();
  }, []);

  async function addDeveloper() {
    const lookup = window.prompt('أدخل @يوزرنيم أو الأيدي الرقمي للمطور الجديد:');
    if (!lookup) return;
    setBusy(true);
    setError(null);
    try {
      await api.post('/admin/developers', { lookup });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'صار خطأ، حاول مرة ثانية.');
    } finally {
      setBusy(false);
    }
  }

  async function removeDeveloper(telegramId: number) {
    if (!window.confirm('متأكد تريد تحذف هذا المطور؟')) return;
    setBusy(true);
    setError(null);
    try {
      await api.del(`/admin/developers/${telegramId}`);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'صار خطأ، حاول مرة ثانية.');
    } finally {
      setBusy(false);
    }
  }

  if (!devs) return <LoadingScreen />;

  return (
    <div>
      {isOwner && (
        <button className="btn btn-primary" style={{ marginBottom: 12 }} disabled={busy} onClick={addDeveloper}>
          ➕ إضافة مطور
        </button>
      )}
      {error && <div className="card" style={{ color: 'var(--danger)' }}>{error}</div>}
      {devs.map((d) => (
        <div className="card" key={d.telegramId}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 800 }}>{d.username ? '@' + d.username : `ID: ${d.telegramId}`}</div>
              <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                {d.role === 'owner' ? '👑 المالك' : '🛠️ مطور'} · ID: {d.telegramId}
                {d.createdAt ? ` · انضم بتاريخ ${new Date(d.createdAt).toLocaleDateString('ar-EG')}` : ''}
              </div>
            </div>
            {isOwner && d.role !== 'owner' && (
              <button
                className="btn btn-secondary"
                style={{ width: 'auto', padding: '8px 14px' }}
                disabled={busy}
                onClick={() => removeDeveloper(d.telegramId)}
              >
                🗑️ حذف
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function PrizesTab() {
  const [prizes, setPrizes] = useState<AdminPrize[] | null>(null);
  const [busyKey, setBusyKey] = useState<string | null>(null);

  async function load() {
    const res = await api.get<{ ok: true; prizes: AdminPrize[] }>('/admin/prizes');
    setPrizes(res.prizes);
  }

  useEffect(() => {
    load();
  }, []);

  async function adjustStock(key: string, action: 'add' | 'remove') {
    const amountStr = window.prompt(action === 'add' ? 'كم تريد أن تضيف؟' : 'كم تريد أن تنقص؟');
    const amount = Number(amountStr);
    if (!amount || amount <= 0) return;
    setBusyKey(key);
    try {
      await api.post(`/admin/prizes/${key}/stock/${action}`, { amount });
      await load();
    } finally {
      setBusyKey(null);
    }
  }

  async function toggleActive(prize: AdminPrize) {
    setBusyKey(prize.key);
    try {
      await api.post(`/admin/prizes/${prize.key}/active`, { isActive: !prize.isActive });
      await load();
    } finally {
      setBusyKey(null);
    }
  }

  if (!prizes) return <LoadingScreen />;

  return (
    <div>
      {prizes.map((p) => (
        <div className="card" key={p.key}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div style={{ fontWeight: 800 }}>{p.name}</div>
            <span className={`status-badge ${p.isActive ? 'status-active' : 'status-expired'}`}>
              {p.isActive ? 'مفعّلة' : 'موقوفة'}
            </span>
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-dim)', margin: '8px 0' }}>
            المخزون: {p.isUnlimited ? '∞' : p.stock} | مُسلَّم: {p.deliveredCount} | قيد التحضير: {p.pendingCount}
          </div>
          {!p.isUnlimited && (
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-secondary" disabled={busyKey === p.key} onClick={() => adjustStock(p.key, 'add')}>
                ➕ إضافة
              </button>
              <button className="btn btn-secondary" disabled={busyKey === p.key} onClick={() => adjustStock(p.key, 'remove')}>
                ➖ إنقاص
              </button>
            </div>
          )}
          <button
            className="btn btn-secondary"
            style={{ marginTop: 8 }}
            disabled={busyKey === p.key}
            onClick={() => toggleActive(p)}
          >
            {p.isActive ? '⏸ إيقاف الجائزة' : '▶️ تفعيل الجائزة'}
          </button>
        </div>
      ))}
    </div>
  );
}

function WithdrawalsTab() {
  const [items, setItems] = useState<Withdrawal[] | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    const res = await api.get<{ ok: true; items: Withdrawal[] }>('/admin/withdrawals');
    setItems(res.items);
  }

  useEffect(() => {
    load();
  }, []);

  async function approve(id: string) {
    setBusyId(id);
    try {
      await api.post(`/admin/withdrawals/${id}/approve`);
      await load();
    } finally {
      setBusyId(null);
    }
  }

  async function reject(id: string) {
    const reason = window.prompt('اكتب سبب الرفض:');
    if (!reason) return;
    setBusyId(id);
    try {
      await api.post(`/admin/withdrawals/${id}/reject`, { reason });
      await load();
    } finally {
      setBusyId(null);
    }
  }

  if (!items) return <LoadingScreen />;
  if (items.length === 0) return <p style={{ textAlign: 'center', color: 'var(--text-dim)' }}>لا توجد طلبات معلقة 🎉</p>;

  return (
    <div>
      {items.map((w) => (
        <div className="card" key={w._id}>
          <div style={{ fontWeight: 800 }}>{w.prizeNameSnapshot}</div>
          <div style={{ fontSize: 13, color: 'var(--text-dim)', margin: '6px 0' }}>
            {w.username ? '@' + w.username : '-'} | ID: {w.telegramId}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
            <button className="btn btn-primary" disabled={busyId === w._id} onClick={() => approve(w._id)}>
              ✅ قبول
            </button>
            <button className="btn btn-secondary" disabled={busyId === w._id} onClick={() => reject(w._id)}>
              ❌ رفض
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

function SettingsTab() {
  const [settings, setSettings] = useState<{ maintenanceMode: boolean } | null>(null);

  async function load() {
    const res = await api.get<{ ok: true; settings: { maintenanceMode: boolean } }>('/admin/settings');
    setSettings(res.settings);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleMaintenance() {
    if (!settings) return;
    await api.post('/admin/settings/maintenance', { enabled: !settings.maintenanceMode });
    await load();
  }

  if (!settings) return <LoadingScreen />;

  return (
    <div className="card">
      <h3 className="card-title">🔧 وضع الصيانة</h3>
      <p className="card-sub">عند التفعيل، يمنع المستخدمون العاديون من استخدام البوت.</p>
      <button className="btn btn-primary" style={{ marginTop: 12 }} onClick={toggleMaintenance}>
        {settings.maintenanceMode ? 'إيقاف وضع الصيانة' : 'تفعيل وضع الصيانة'}
      </button>
    </div>
  );
}

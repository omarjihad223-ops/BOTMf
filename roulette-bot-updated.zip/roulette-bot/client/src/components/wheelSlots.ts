export interface WheelSlot {
  key: string;
  icon: string;
  label: string;
}

// Visual arrangement only — rare-looking prizes are spread apart so they never sit
// next to each other, per the design spec. This ordering has NO relationship to the
// actual server-side probability of winning each one.
export const WHEEL_SLOTS: WheelSlot[] = [
  { key: 'gems_3000', icon: '💎', label: '3000' },
  { key: 'nft_black', icon: '🖤', label: 'NFT' },
  { key: 'stars_15', icon: '⭐', label: '15' },
  { key: 'asia_credit_300', icon: '📱', label: '300' },
  { key: 'asia_credit_1', icon: '📱', label: '1' },
  { key: 'stars_1000', icon: '⭐', label: '1000' },
  { key: 'gems_5000', icon: '💎', label: '5000' },
  { key: 'extreme_account_20', icon: '⚡', label: '20' },
  { key: 'stars_25', icon: '⭐', label: '25' },
  { key: 'gems_7000', icon: '💎', label: '7000' },
  { key: 'asia_credit_5', icon: '📱', label: '5' },
  { key: 'stars_200', icon: '⭐', label: '200' },
  { key: 'asia_credit_140', icon: '📱', label: '140' },
  { key: 'stars_400', icon: '⭐', label: '400' },
  { key: 'nft_normal', icon: '🎁', label: 'NFT' },
];

export function findSlotIndexForKey(key: string | undefined): number {
  if (!key) return Math.floor(Math.random() * WHEEL_SLOTS.length);
  const idx = WHEEL_SLOTS.findIndex((s) => s.key === key);
  return idx === -1 ? Math.floor(Math.random() * WHEEL_SLOTS.length) : idx;
}
